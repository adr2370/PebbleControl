/************************************************************************************
  This is your background code.
  For more information please visit our wiki site:
  http://docs.crossrider.com/#!/guide/scopes_background
*************************************************************************************/

appAPI.ready(function() {
    // Sets the resource path for the popup
    appAPI.browserAction.setResourceIcon('icon.png');
    
    appAPI.browserAction.setTitle('My Crossrider Extension');
    
    var s='<!DOCTYPE html> <html> <head> <script type="text/javascript"> function crossriderMain($) { $("input").keyup(function(event){ if(event.keyCode == 13){ appAPI.db.set("serial", $("input").val()); appAPI.message.toAllOtherTabs({action: "serial", value: $("input").val()}); appAPI.browserAction.closePopup(); } }); } </script> <style> input { font-size:18px;width:145px } </style> </head> <body> <input> </body> </html>';
    appAPI.browserAction.setPopup({
        html:s,
        height: 30,
        width: 150
    });
});

var lid = appAPI.message.addListener(function(msg) {
	// Performs action according to message type received
	switch (msg.type) {
		// Received message to broadcast to all tabs
		case 'all': appAPI.message.toAllTabs(msg); break;
		// Received message to broadcast to all tabs
		//case 'other': appAPI.message.toAllOtherTabs(msg); break;
		// Received message to send to the active tab
		case 'tab': appAPI.message.toActiveTab(msg); break;
		// Received message to remove listeners; Relay message all tabs, and then remove background listener
		case 'remove': appAPI.message.toAllTabs(msg); appAPI.message.removeListener(lid); break;
		// Received message to broadcast to all iframes on the active tab
		//case 'iframes': appAPI.message.toCurrentTabIframes(msg); break;
		// Received message to send to the iframe's parent page
		//case 'window': appAPI.message.toCurrentTabWindow(msg); break;
	}
});